---
uid: udos-guide-survival-20260129170100-UTC-L300AB65
title: Shelter Construction Guide
tags: [guide, knowledge, survival]
status: living
updated: 2026-01-30
spec: wiki_spec_obsidian.md
authoring-rules:
- Knowledge guides use 'guide' tag
- Content organized by technique/category
- File-based, offline-first
---


# Shelter Construction Guide

**Category:** Survival Skills
**Priority:** Critical ████████████
**Time Required:** 1-4 hours
**Difficulty:** Beginner to Advanced

---

## Overview

Shelter is your second priority after immediate danger. Master these 8 shelter types and you can survive any environment.

**Shelter Priority Ranking:**
```
╔═══════════════╦══════════╦══════════╦══════════╦══════════╗
║ Shelter Type  ║ Speed    ║ Warmth   ║ Weather  ║ Effort   ║
╠═══════════════╬══════════╬══════════╬══════════╬══════════╣
║ Debris Hut    ║ ████████ ║ ████████ ║ ██████   ║ ██████   ║
║ Lean-To       ║ ████████ ║ ████     ║ ████     ║ ████████ ║
║ A-Frame       ║ ██████   ║ ██████   ║ ██████   ║ ████     ║
║ Tarp Shelter  ║ ████████ ║ ██       ║ ██████   ║ ████████ ║
║ Snow Cave     ║ ████     ║ ████████ ║ ████████ ║ ██       ║
║ Wickiup       ║ ████     ║ ██████   ║ ██████   ║ ████     ║
║ Emergency Bag ║ ████████ ║ ██████   ║ ████     ║ ████████ ║
║ Dugout        ║ ██       ║ ████████ ║ ████████ ║ ██       ║
╚═══════════════╩══════════╩══════════╩══════════╩══════════╝

████████ = Excellent, ██████ = Good, ████ = Fair, ██ = Poor
```

---

## 1. Debris Hut (Best All-Around)

**Use:** Cold weather, minimal tools, solo shelter

**Capacity:** 1 person
**Build Time:** 2-3 hours
**Warmth:** ████████ Excellent

### Construction Diagram

```
Side View (Complete):
                    Ridge Pole
                 ┌─────────────┐
                ╱               ╲
               ╱ ▓▓▓▓▓▓▓▓▓▓▓▓▓  ╲  ← Debris 12-18"
              ╱  ▒▒▒▒▒▒▒▒▒▒▒▒▒   ╲
             ╱   ░░░░░░░░░░░░░░   ╲
            ╱    ░Sleeping░Area░   ╲
           ╱     ░░░░░░░░░░░░░░░    ╲
          └──────────────────────────┘
         Support    Frame         Support
          Post      Ribs           Post

Front View:
           Ridge Pole
          ╱────────╲
         ╱          ╲
        ╱ ▓▓▓▓▓▓▓▓▓ ╲
       ╱  ▒▒▒▒▒▒▒▒▒  ╲
      ╱   ░░░░░░░░░   ╲
     ╱    ░░░░○░░░░    ╲  ← Entry (crawl in)
    └─────────────────┘

Top View:
    Ridge Pole
    ════════════
   ╱            ╲
  ╱ ▓▓▓▓▓▓▓▓▓▓▓ ╲
 │  ▒Ribs▒every ▒ │
 │  ░░12░inches░░ │
  ╲  ░at░45°░░░  ╱
   ╲ ░░░░░░░░░░ ╱
    ╲          ╱
     ══════════
```

### Step-by-Step

```
Step 1: Ridge Pole
    Support        Ridge Pole 9-10 ft        Support
    Tree/Fork      ═══════════════════        Tree/Fork
      │                                         │
      ○───────────────────────────────────────○
     3ft                                      3ft
     high                                    high

Step 2: Frame Ribs (every 12")
         ╱│╲
        ╱ │ ╲
       ╱  │  ╲  ← Ribs at 45° angle
      ╱   │   ╲
     ╱    │    ╲
    ═══════════════

Step 3: Lattice Layer
    ═══════════
    ║║║║║║║║║║║  ← Small branches
    ═══════════    horizontal

Step 4: Debris Layers
    ▓▓▓▓▓▓▓▓▓▓▓  ← Leaves/pine needles (8")
    ▒▒▒▒▒▒▒▒▒▒▒  ← Grass/small debris (6")
    ░░░░░░░░░░░  ← Bark/large leaves (4")
    ═══════════  Frame

Total debris: 12-18 inches minimum
```

### Interior Setup

```
Cross Section:
    ▓▓▓▓▓▓▓▓▓▓▓▓▓  ← Debris layer
    ░░░░░░░░░░░░░  Frame
    ═════════════
    ≈≈≈≈≈≈≈≈≈≈≈≈≈  ← Insulation bed (leaves)
    ─────────────  Ground

Sleeping Position:
    ▓▓▓▓Debris▓▓▓
    ░░░░Frame░░░░
    ═════════════
    ◯←Head  Feet→ (plug entry with backpack)
    ≈≈≈≈≈≈≈≈≈≈≈≈≈
```

### Materials Needed

✓ Ridge pole: 9-10 ft, 2-3" diameter
✓ Ribs: 30-40 sticks, 6-8 ft long
✓ Lattice: 50+ small branches
✓ Debris: HUGE pile (3x shelter size)
✓ Bedding: Thick layer of leaves/pine

---

## 2. Lean-To (Quick Build)

**Use:** Quick shelter, rain protection, temporary camp

**Capacity:** 1-2 people
**Build Time:** 30-60 minutes
**Warmth:** ████ Fair (add fire in front)

### Construction Diagram

```
Side View:
    Ridge Pole
    ═══════════════════
    ║                 ║
    ║    ▓▓▓▓▓▓▓▓▓▓   ║  ← Covering
    ║   ▒▒▒▒▒▒▒▒▒▒▒   ║
    ║  ░░░░░░░░░░░░░  ║
    ║ ░Sleeping░Area░ ║
    ║░░░░░░░░░░░░░░░░ ║
    ●═════════════════●
   Support         Support
   (trees)         (trees)

Front View:
         Ridge Pole 6-7 ft high
         ═══════════
        ╱           ╲
       ╱ ▓▓▓▓▓▓▓▓▓  ╲
      ╱  ▒▒▒▒▒▒▒▒▒   ╲
     ╱   ░░░░░░░░░    ╲
    ╱    ░░░░░░░░░     ╲
   ●─────────────────────● Ground level
   │                     │
   ●─────────────────────● (45° angle)
   │     Open front      │
   └─────────────────────┘

    🔥  Fire here (3-4 ft away)
```

### Enhanced with Reflector

```
Add heat reflector behind fire:

    Ridge         Shelter
    ═══           ▓▓▓▓▓
    ║║║          ▒▒▒▒▒▒
    ║║║ ←─      ░░░Sleep
Reflector       ░░░Area░
  wall          ░░░░░░░░
    ║║║          ═══════
    ║║║
    ═══

         🔥 Fire

    Heat reflects back ───→ Warmer!
```

### Materials

✓ Ridge pole: 8-10 ft
✓ Support poles: 4-6, forked if possible
✓ Lean poles: 10-15, 7-8 ft long
✓ Cover: Branches, bark, tarp, or debris
✓ Cordage: For lashing (optional)

---

## 3. A-Frame Shelter

**Use:** Strong structure, good insulation, semi-permanent

**Capacity:** 1-2 people
**Build Time:** 2-3 hours
**Warmth:** ██████ Good

### Construction Diagram

```
Front View:
         Ridge Pole
           ╱══╲
          ╱    ╲
         ╱ ▓▓▓▓ ╲
        ╱  ▒▒▒▒  ╲
       ╱   ░░░░   ╲
      ╱    ░░░░    ╲
     ╱     ░  ░     ╲
    ╱      ░○░░      ╲  ← Entry
   ═══════════════════
   Side      Side
   Pole      Pole

Side View:
    Ridge Pole
    ═════════════════════
   ╱│╲                 ╱│╲
  ╱ │ ╲               ╱ │ ╲
 ╱  │  ╲             ╱  │  ╲
═════════════════════════════
     │                   │
   Cross               Cross
   Brace               Brace

Top View:
    Entry
      ▼
    ┌───┐
    │   │
    │▓▓▓│  ← Frame structure
    │▒▒▒│
    │░░░│
    │░░░│  Ridge pole
    │░░░│  runs length
    │░░░│
    └───┘
    10-12 ft
```

### Frame Assembly

```
Step 1: Tripod ends
    ╱│╲        ╱│╲
   ╱ │ ╲      ╱ │ ╲
  ╱  │  ╲    ╱  │  ╲
 ●───●───●  ●───●───●
 Lash here  Lash here

Step 2: Add ridge pole
 ╱│╲═════════════╱│╲
 Tripod  Ridge   Tripod
  End    Pole     End

Step 3: Side poles (both sides)
    ╱══╲
   ╱    ╲
  ╱      ╲
 ●────────● Every 12-18"
```

### Materials

✓ Ridge pole: 10-12 ft, sturdy
✓ End poles: 6 poles, 5-6 ft
✓ Side poles: 20-30, 5-6 ft
✓ Cordage: Strong lashings
✓ Cover: Tarp, bark, or debris

---

## 4. Tarp Configurations

**Use:** Fastest shelter with gear

**Capacity:** 1-4 people (depending on size)
**Build Time:** 10-20 minutes
**Warmth:** ██ Poor (wind protection only)

### A-Frame Tarp

```
Side View:
    Ridge Line (rope)
    ══════════════════
   ╱                  ╲
  ╱ Tarp               ╲
 ╱  ████████████████    ╲
╱   ████████████████     ╲
│                         │
●─────────────────────────●
Stakes    Open    Stakes

Front View:
    Ridge Line
    ════════
   ╱        ╲
  ╱          ╲
 ╱████████████╲
╱  ░░Sleep░░   ╲
●───────────────●
```

### Diamond/Flying Tent

```
Top View:
       Stake
         │
         ○
        ╱ ╲
       ╱   ╲
      ╱█████╲
     ╱███████╲
    ●─────────●  ← Center pole
   ╱           ╲
  ╱             ╲
 ○               ○
Stake          Stake

Front View:
      │ Pole
      │
     ╱█╲
    ╱███╲
   ╱░░░░░╲  ← Good headroom
  ╱░Sleep░╲
 ●─────────●
```

### Lean-To Tarp

```
Side View:
Ridge Line (high)
══════════════
│████████████║
│████████████║  ← Tarp
│░░░Sleep░░░░║
└─────────────●
Stakes     Ground stake

    🔥  Fire in front
```

### 6 Tarp Configurations

```
1. A-Frame       2. Lean-To       3. Diamond
   ╱══╲             ╱══            ╱╲
  ╱    ╲           ╱   ╲          ╱  ╲
 ●──────●         ●─────●        ●────●

4. C-Fly         5. Wedge         6. Burrito
   ╭──╮            ╱│              ○──○
   │  │           ╱ │            ╱    ╲
   ●──●          ●──●           ●──────●
```

---

## 5. Snow Cave (Winter)

**Use:** Deep snow only (4+ ft), emergency winter shelter

**Capacity:** 1-3 people
**Build Time:** 2-4 hours
**Warmth:** ████████ Excellent (32°F inside)

### Construction Diagram

```
Side Cross-Section:
    Snow Surface
    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
    ▓▓▓╔═════════════╗▓▓▓▓▓▓▓
    ▓▓▓║ Sleeping    ║▓▓▓▓▓▓▓  ← 12-18" thick
    ▓▓▓║ Platform    ║▓▓▓▓▓▓▓
    ▓▓▓╠═════════════╣▓▓▓▓▓▓▓
    ▓▓▓║   ░Entry░   ║▓▓▓▓▓▓▓
    ▓▓▓║   ░Tunnel░  ║▓▓▓▓▓▓▓  ← Lower than
    ▓▓▓╚══○══════════╝▓▓▓▓▓▓▓    sleeping area
    ═══════════════════════════
    Ground Level

Top View:
    Snow
    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
    ▓╔═══════════╗▓
    ▓║ Sleeping  ║▓  ← Dome shape
    ▓║   Area    ║▓     6-8 ft wide
    ▓║           ║▓
    ▓╚═══════════╝▓
    ▓▓▓▓▓║░Entry░║▓▓
    ▓▓▓▓▓║░Tunnel║▓▓
    ▓▓▓▓▓╚═══════╝▓▓
    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
```

### Key Features

```
Ventilation Hole (CRITICAL!):
    ▲ Vent
    │ (fist-sized)
    │
  ▓▓●▓▓  ← Poke from inside
  ▓▓▓▓▓
  ▓Cave

Cold Well:
  ╔════════╗
  ║ Sleep  ║ ← Warm air rises
  ╠════════╣
  ║ Entry  ║ ← Cold air sinks
  ╚════════╝

Sleeping Platform:
  Higher than entry = warmer
  ╔════════╗ 18-24" higher
  ║ ≈≈≈≈≈≈ ║ than tunnel
  ╠════════╣
  ║░Tunnel░║
```

### Safety

⚠️ **ALWAYS dig vent hole**
⚠️ Keep shovel inside
⚠️ Mark entrance from outside
⚠️ Monitor for collapse
⚠️ No candles (CO poisoning risk)

---

## 6. Wickiup (Conical Lodge)

**Use:** Group shelter, semi-permanent, native design

**Capacity:** 3-6 people
**Build Time:** 4-6 hours
**Warmth:** ██████ Good (with fire inside)

### Construction Diagram

```
Frame Structure:
       ╱│╲
      ╱ │ ╲
     ╱  │  ╲
    ╱   │   ╲    12-15 poles
   ╱    │    ╲   meet at top
  ╱     │     ╲
 ╱      │      ╲
●───────●───────● Base circle
                  15-20 ft diameter

Top View:
       ○ Tie point
      ╱│╲
     ╱ │ ╲
    ╱  │  ╲
   │   │   │
   │   │   │  Poles every
   │   ●   │  12-18 inches
   │  ╱│╲  │
   │ ╱ │ ╲ │
   ●───────●
  Circle base

Covered:
       ▲
      ╱▓╲
     ╱▓▓▓╲
    ╱▓▓▓▓▓╲
   ╱▓▓▓▓▓▓▓╲   ← Bark/debris
  ╱░░░○░░░░░╲  ← Door
 ╱░░Interior░░╲
●─────────────●
```

### Interior Layout

```
With Fire:
    ▓▓▓▓▓▓▓▓▓
   ╱         ╲
  ╱  Smoke   ╲
 │   Hole     │ ← Leave top open
 │     ▲      │   for smoke
 │     ║      │
 │    🔥      │ ← Fire center
 │  ╱  │  ╲  │
 │ ○   ●   ○ │ ← People around
  ╲         ╱
   ╲░░░○░░░╱
    ═══════
```

---

## 7. Emergency Bivvy

**Use:** Immediate emergency, overnight survival

**Capacity:** 1 person
**Build Time:** 5-10 minutes
**Warmth:** ██████ Good (with quality gear)

### Configurations

```
1. Trash Bag Bivvy:
   ╔═══════════╗
   ║ ░░░░░░░░░ ║ ← Cut hole for head
   ║ ░░Body░░░ ║   Sit with bag
   ║ ░Insulation║   around body
   ╚═══════════╝

2. Emergency Blanket:
    ═══╗
   ║███║  ← Reflective side
   ║░░░║     toward body
   ║░Body
   ║░░░║
   ════╝

3. Leaf Bag Cocoon:
   ╔═════════╗
   ║▓▓▓▓▓▓▓▓▓║ ← Fill with leaves
   ║▒▒Body▒▒▒║   Insulation
   ║░░░░░░░░░║
   ╚═════════╝

4. Ground Insulation:
   ▓▓▓▓▓▓▓▓▓▓  Body
   ▒▒▒▒▒▒▒▒▒▒  Debris/leaves
   ══════════  Ground
```

---

## 8. Dugout Shelter

**Use:** Long-term, cold climate, earth insulation

**Capacity:** 1-2 people
**Build Time:** 6-10 hours
**Warmth:** ████████ Excellent

### Construction

```
Side Cross-Section:
    ▓Roof▓Layer▓
    ▓▓▓▓▓▓▓▓▓▓▓▓
    ░Logs/Poles░
    ═══════════════
   ╱               ╲
  ╱ Interior 6 ft   ╲ 3-4 ft
 ╱  wide            ╲ deep
╱░░░░░Sleep░░░░░░░░░╲
══════════════════════
      Excavated

Entry:
  ▓▓▓▓▓▓▓▓▓▓▓
  ║░░Steps░░║
  ║░░░░░░░░░║
  ║░░░○░░░░░║ ← Door
  ╚═════════╝

Roof Detail:
  ▓▓▓▓▓▓▓▓▓▓  Sod/dirt 6-8"
  ░░░░░░░░░░  Bark layer
  ══════════  Logs/poles
  ║        ║  Support posts
  ╚════════╝  Interior
```

---

## Shelter Selection Matrix

```
╔══════════════╦═══════╦═══════╦═══════╦═══════╦═══════╗
║ Environment  ║ Fast  ║ Warm  ║ Solo  ║ Group ║ Tools ║
╠══════════════╬═══════╬═══════╬═══════╬═══════╬═══════╣
║ Forest       ║ Lean  ║ Debris║ Debris║ Wickip║ A-Fram║
║ Snow         ║ Cave  ║ Cave  ║ Cave  ║ Igloo ║ Cave  ║
║ Plains       ║ Tarp  ║ Dugout║ Debris║ Tarp  ║ Dugout║
║ Desert       ║ Tarp  ║ Dugout║ Debris║ Tarp  ║ Dugout║
║ Emergency    ║ Bivvy ║ Debris║ Bivvy ║ Tarp  ║ Lean  ║
╚══════════════╩═══════╩═══════╩═══════╩═══════╩═══════╝
```

---

## Materials Checklist

### Natural Materials
- [ ] Ridge poles (long, sturdy)
- [ ] Frame poles (medium, straight)
- [ ] Lattice branches (small, flexible)
- [ ] Debris (huge quantity!)
- [ ] Bedding material (leaves, pine, grass)
- [ ] Bark (large pieces for covering)
- [ ] Cordage (vines, roots, stripped bark)

### Manufactured Materials
- [ ] Tarp (8×10 minimum)
- [ ] Rope/paracord (50+ ft)
- [ ] Emergency blanket
- [ ] Trash bags (heavy duty)
- [ ] Duct tape
- [ ] Stakes (or make from wood)

---

## Related Resources

- **Knot Tying:** `knowledge/survival/skills/knot-tying.md`
- **Site Selection:** `knowledge/survival/outdoors/campsite-selection.md`
- **Fire Building:** `knowledge/survival/fire/fire-starting.md`
- **Insulation:** `knowledge/survival/cold-weather/hypothermia-prevention.md`

---

**Priority:** ████████████ **CRITICAL SKILL**

Practice shelter building before you need it!
